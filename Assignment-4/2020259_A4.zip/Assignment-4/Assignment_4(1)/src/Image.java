
public interface Image {
	void update();
	void display();
}
