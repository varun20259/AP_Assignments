package com.company;

public class Person {
}
