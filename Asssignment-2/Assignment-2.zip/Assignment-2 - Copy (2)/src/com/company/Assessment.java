package com.company;

public interface Assessment {

    void View_assessments(String id,Instructor j);

    void Logout();
}
