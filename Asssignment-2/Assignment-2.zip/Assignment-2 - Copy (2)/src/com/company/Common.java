package com.company;

public class Common {

}
