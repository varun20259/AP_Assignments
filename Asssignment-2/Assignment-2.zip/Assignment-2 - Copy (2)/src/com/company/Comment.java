package com.company;

public interface Comment{

    void View_comment(String id);
    void Add_comment(String id);
}